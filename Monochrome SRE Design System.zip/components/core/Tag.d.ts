export interface TagProps {
  children: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Button — primary interactive element. Variants: primary, secondary, ghost.
 *
 * @example
 * <Button variant="primary">Deploy</Button>
 * <Button variant="secondary" size="sm">View Runbook</Button>
 * <Button variant="ghost" href="/resume">Resume ↗</Button>
 */

export function Button({ variant = 'primary', size = 'md', href, disabled, children, onClick, style, ...rest }) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '6px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-medium)',
    letterSpacing: 'var(--tracking-tight)',
    border: '1px solid transparent',
    borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    textDecoration: 'none',
    transition: 'background-color var(--duration-fast) var(--ease-default), color var(--duration-fast) var(--ease-default), border-color var(--duration-fast) var(--ease-default), transform var(--duration-fast) var(--ease-default)',
    outline: 'none',
    userSelect: 'none',
    whiteSpace: 'nowrap',
  };

  const sizes = {
    sm: { fontSize: 'var(--text-xs)',  padding: '5px 12px',  lineHeight: 1 },
    md: { fontSize: 'var(--text-sm)',  padding: '8px 18px',  lineHeight: 1 },
    lg: { fontSize: 'var(--text-base)', padding: '11px 24px', lineHeight: 1 },
  };

  const variants = {
    primary: {
      background: 'var(--accent)',
      color: 'var(--accent-text)',
      borderColor: 'var(--accent)',
    },
    secondary: {
      background: 'transparent',
      color: 'var(--text)',
      borderColor: 'var(--border-strong)',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-muted)',
      borderColor: 'transparent',
    },
  };

  const combinedStyle = { ...base, ...sizes[size], ...variants[variant], ...style };

  const handleMouseEnter = (e) => {
    if (disabled) return;
    if (variant === 'primary') {
      e.currentTarget.style.opacity = '0.85';
      e.currentTarget.style.transform = 'translateY(-1px)';
    } else if (variant === 'secondary') {
      e.currentTarget.style.borderColor = 'var(--text)';
      e.currentTarget.style.transform = 'translateY(-1px)';
    } else {
      e.currentTarget.style.color = 'var(--text)';
    }
  };
  const handleMouseLeave = (e) => {
    if (disabled) return;
    e.currentTarget.style.opacity = variant === 'primary' ? '1' : '1';
    e.currentTarget.style.transform = '';
    e.currentTarget.style.borderColor = variants[variant].borderColor;
    e.currentTarget.style.color = variants[variant].color;
  };

  const props = {
    style: combinedStyle,
    disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: handleMouseEnter,
    onMouseLeave: handleMouseLeave,
    onFocus: (e) => { e.currentTarget.style.outline = '2px solid var(--accent)'; e.currentTarget.style.outlineOffset = '3px'; },
    onBlur:  (e) => { e.currentTarget.style.outline = 'none'; },
    ...rest,
  };

  if (href) {
    return React.createElement('a', { href, ...props }, children);
  }
  return React.createElement('button', { type: 'button', ...props }, children);
}

Small monospaced pill for tech-stack labels.

```jsx
<Tag>AWS</Tag>
<Tag>Kubernetes</Tag>
<Tag>Terraform</Tag>
```

Place in a flex container with `gap: 6px` for a tag cloud row.
Text is auto-uppercased via CSS.

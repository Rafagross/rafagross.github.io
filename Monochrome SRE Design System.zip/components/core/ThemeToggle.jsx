/**
 * ThemeToggle — sun/moon icon button to switch light ↔ dark theme.
 * Reads/writes data-theme on <html>. Persists to localStorage.
 *
 * @example
 * <ThemeToggle />
 */

export function ThemeToggle({ style }) {
  const [isDark, setIsDark] = React.useState(() => {
    if (typeof document === 'undefined') return false;
    return document.documentElement.getAttribute('data-theme') === 'dark';
  });

  const toggle = () => {
    const next = isDark ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('sre-theme', next); } catch {}
    setIsDark(!isDark);
  };

  const [hovered, setHovered] = React.useState(false);

  // Sun icon (light mode indicator)
  const SunIcon = React.createElement('svg', {
    width: 16, height: 16, viewBox: '0 0 24 24',
    fill: 'none', stroke: 'currentColor', strokeWidth: 1.5,
    strokeLinecap: 'round', strokeLinejoin: 'round',
    'aria-hidden': 'true',
  },
    React.createElement('circle', { cx: 12, cy: 12, r: 5 }),
    React.createElement('line', { x1: 12, y1: 1, x2: 12, y2: 3 }),
    React.createElement('line', { x1: 12, y1: 21, x2: 12, y2: 23 }),
    React.createElement('line', { x1: 4.22, y1: 4.22, x2: 5.64, y2: 5.64 }),
    React.createElement('line', { x1: 18.36, y1: 18.36, x2: 19.78, y2: 19.78 }),
    React.createElement('line', { x1: 1, y1: 12, x2: 3, y2: 12 }),
    React.createElement('line', { x1: 21, y1: 12, x2: 23, y2: 12 }),
    React.createElement('line', { x1: 4.22, y1: 19.78, x2: 5.64, y2: 18.36 }),
    React.createElement('line', { x1: 18.36, y1: 5.64, x2: 19.78, y2: 4.22 })
  );

  // Moon icon (dark mode indicator)
  const MoonIcon = React.createElement('svg', {
    width: 16, height: 16, viewBox: '0 0 24 24',
    fill: 'none', stroke: 'currentColor', strokeWidth: 1.5,
    strokeLinecap: 'round', strokeLinejoin: 'round',
    'aria-hidden': 'true',
  },
    React.createElement('path', { d: 'M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z' })
  );

  return React.createElement('button', {
    type: 'button',
    'aria-label': isDark ? 'Switch to light mode' : 'Switch to dark mode',
    onClick: toggle,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    onFocus: (e) => { e.currentTarget.style.outline = '2px solid var(--accent)'; e.currentTarget.style.outlineOffset = '3px'; },
    onBlur:  (e) => { e.currentTarget.style.outline = 'none'; },
    style: {
      background: 'transparent',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      color: hovered ? 'var(--text)' : 'var(--text-muted)',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: '34px',
      height: '34px',
      padding: 0,
      transition: 'color var(--duration-fast) var(--ease-default), border-color var(--duration-fast) var(--ease-default)',
      borderColor: hovered ? 'var(--border-strong)' : 'var(--border)',
      outline: 'none',
      flexShrink: 0,
      ...style,
    }
  }, isDark ? SunIcon : MoonIcon);
}

Monospaced label for severity, status, and classification markers.

```jsx
<Badge variant="severity" level="P2">P2</Badge>
<Badge variant="severity" level="P3">P3</Badge>
<Badge variant="featured">Featured</Badge>
<Badge variant="stable">stable</Badge>
<Badge variant="active">active</Badge>
```

Notable props: `variant` controls the visual weight; `level` (P1/P2/P3) used with `variant="severity"`.
All text is forced uppercase + JetBrains Mono to carry the SRE industrial identity.

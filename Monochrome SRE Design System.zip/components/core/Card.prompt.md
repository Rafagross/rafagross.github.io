Base surface with a mouse-tracking radial spotlight and lift-on-hover animation.

```jsx
<Card>
  <h3>Project title</h3>
  <p>Description text here.</p>
</Card>

<Card href="/projects/cloudops" as="a">
  Clickable card — renders as <a>, cursor: pointer
</Card>
```

Notable: the spotlight tracks --mouse-x / --mouse-y CSS variables updated via onMouseMove.
Override `padding` prop to adjust internal whitespace; default is var(--card-pad) = 24px.

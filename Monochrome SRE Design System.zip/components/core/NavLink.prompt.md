Navigation anchor with an animated underline that slides in from left on hover.

```jsx
<NavLink href="#projects">Projects</NavLink>
<NavLink href="#runbooks" active>Runbooks</NavLink>  {/* active keeps underline */}
```

The underline is a positioned <span> that transitions width 0→100%.
`active` prop holds the underline open for the current page/section.

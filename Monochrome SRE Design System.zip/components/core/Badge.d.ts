export interface BadgeProps {
  /** Visual category */
  variant?: 'default' | 'featured' | 'active' | 'stable' | 'severity' | 'status';
  /** Severity level — used when variant="severity" */
  level?: 'P1' | 'P2' | 'P3';
  /** Status label — used when variant="status" */
  status?: 'stable' | 'active' | 'deprecated';
  children: React.ReactNode;
  style?: React.CSSProperties;
}

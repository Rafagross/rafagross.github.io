/**
 * Tag — tech-stack label. Small, monospaced, uppercase pill.
 * Used in project cards and runbook metadata.
 *
 * @example
 * <Tag>AWS</Tag>
 * <Tag>Kubernetes</Tag>
 * <Tag>Terraform</Tag>
 */

export function Tag({ children, style }) {
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: '11px',
      fontWeight: 'var(--fw-medium)',
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      background: 'var(--bg-subtle)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-full)',
      padding: '3px 9px',
      lineHeight: 1.4,
      whiteSpace: 'nowrap',
      ...style,
    }
  }, children);
}

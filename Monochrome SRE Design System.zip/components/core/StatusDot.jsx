/**
 * StatusDot — animated green "Available" indicator.
 * The ONLY element in the system that uses a non-grayscale color.
 *
 * @example
 * <StatusDot /> Available for new roles
 */

export function StatusDot({ label = 'Available for new roles', style }) {
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '8px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-muted)',
      letterSpacing: '0.04em',
      ...style,
    }
  },
    React.createElement('span', {
      style: {
        position: 'relative',
        width: '8px',
        height: '8px',
        borderRadius: '50%',
        background: 'var(--green)',
        flexShrink: 0,
        display: 'inline-block',
      }
    },
      React.createElement('span', {
        style: {
          position: 'absolute',
          inset: '-3px',
          borderRadius: '50%',
          background: 'var(--green)',
          opacity: 0,
          animation: 'status-pulse 2.4s cubic-bezier(.4,0,.6,1) infinite',
        }
      })
    ),
    label
  );
}

// Inject keyframes once
if (typeof document !== 'undefined' && !document.getElementById('status-dot-style')) {
  const s = document.createElement('style');
  s.id = 'status-dot-style';
  s.textContent = `
    @keyframes status-pulse {
      0%, 100% { opacity: 0; transform: scale(1); }
      50% { opacity: 0.35; transform: scale(2.2); }
    }
    @media (prefers-reduced-motion: reduce) {
      @keyframes status-pulse { 0%, 100% { opacity: 0; } }
    }
  `;
  document.head.appendChild(s);
}

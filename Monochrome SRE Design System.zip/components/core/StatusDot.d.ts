export interface StatusDotProps {
  /** Label text next to the dot. Default: "Available for new roles" */
  label?: string;
  style?: React.CSSProperties;
}

export interface CardProps {
  /** HTML element to render — defaults to 'div' */
  as?: string;
  /** Renders as <a> with spotlight when provided */
  href?: string;
  /** Override internal padding (default: var(--card-pad)) */
  padding?: string;
  children: React.ReactNode;
  style?: React.CSSProperties;
}

export interface NavLinkProps {
  href: string;
  /** Marks the link as current — keeps underline visible */
  active?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
}

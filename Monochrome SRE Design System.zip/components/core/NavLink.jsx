/**
 * NavLink — navigation anchor with animated underline on hover/active.
 *
 * @example
 * <NavLink href="#projects">Projects</NavLink>
 * <NavLink href="#runbooks" active>Runbooks</NavLink>
 */

export function NavLink({ href, active, children, style }) {
  const [hovered, setHovered] = React.useState(false);

  return React.createElement('a', {
    href,
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--fw-medium)',
      color: active || hovered ? 'var(--text)' : 'var(--text-muted)',
      textDecoration: 'none',
      letterSpacing: 'var(--tracking-tight)',
      padding: '4px 0',
      transition: 'color var(--duration-fast) var(--ease-default)',
      outline: 'none',
      ...style,
    },
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    onFocus: (e) => { setHovered(true); e.currentTarget.style.outline = '2px solid var(--accent)'; e.currentTarget.style.outlineOffset = '4px'; },
    onBlur:  (e) => { setHovered(false); e.currentTarget.style.outline = 'none'; },
  },
    children,
    React.createElement('span', {
      'aria-hidden': 'true',
      style: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        width: active || hovered ? '100%' : '0%',
        height: '1px',
        background: 'var(--accent)',
        transition: 'width var(--duration-normal) var(--ease-default)',
      }
    })
  );
}

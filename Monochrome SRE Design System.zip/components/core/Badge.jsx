/**
 * Badge — monospaced label for severity, status, and classification.
 * Used in runbook cards (P2/P3) and project cards (Featured/Active).
 *
 * @example
 * <Badge variant="severity" level="P2">P2</Badge>
 * <Badge variant="status" status="stable">stable</Badge>
 * <Badge variant="featured">Featured</Badge>
 */

export function Badge({ variant = 'default', level, status, children, style }) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '5px',
    fontFamily: 'var(--font-mono)',
    fontSize: 'var(--text-2xs)',
    fontWeight: 'var(--fw-semibold)',
    letterSpacing: 'var(--tracking-label)',
    textTransform: 'uppercase',
    borderRadius: 'var(--radius-sm)',
    padding: '3px 8px',
    border: '1px solid',
    lineHeight: 1.4,
    whiteSpace: 'nowrap',
  };

  const severityStyles = {
    P1: { color: 'var(--text)',       borderColor: 'var(--border-strong)', background: 'var(--surface-raised)' },
    P2: { color: 'var(--text)',       borderColor: 'var(--border-strong)', background: 'var(--surface-raised)' },
    P3: { color: 'var(--text-muted)', borderColor: 'var(--border)',        background: 'transparent' },
  };

  const variants = {
    default:  { color: 'var(--text-muted)', borderColor: 'var(--border)',        background: 'transparent' },
    featured: { color: 'var(--accent)',     borderColor: 'var(--accent)',         background: 'transparent' },
    active:   { color: 'var(--text)',       borderColor: 'var(--border-strong)', background: 'var(--surface-raised)' },
    stable:   { color: 'var(--text-muted)', borderColor: 'var(--border)',        background: 'transparent' },
    severity: severityStyles[level] || severityStyles.P3,
    status:   { color: 'var(--text-muted)', borderColor: 'var(--border)',        background: 'transparent' },
  };

  const chosen = variants[variant] || variants.default;
  return React.createElement('span', { style: { ...base, ...chosen, ...style } }, children);
}

Sun/moon icon button. Reads/writes `data-theme` attribute on `<html>` and persists to localStorage under the key `sre-theme`.

```jsx
<ThemeToggle />
```

No props required. Detects current theme on mount from the HTML attribute.
Place in the navigation bar, aligned to the right of nav links.

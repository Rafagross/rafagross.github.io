export interface ThemeToggleProps {
  style?: React.CSSProperties;
}

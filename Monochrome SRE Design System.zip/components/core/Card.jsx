/**
 * Card — base surface with spotlight hover effect.
 * Hover: border strengthens, card lifts, a radial spotlight follows the mouse.
 *
 * @example
 * <Card>Content here</Card>
 * <Card as="a" href="/projects/foo">Linked card</Card>
 */

export function Card({ as = 'div', href, children, style, padding, ...rest }) {
  const ref = React.useRef(null);

  const handleMouseMove = React.useCallback((e) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    el.style.setProperty('--mouse-x', x + '%');
    el.style.setProperty('--mouse-y', y + '%');
  }, []);

  const handleMouseEnter = React.useCallback((e) => {
    const el = ref.current;
    if (!el) return;
    el.style.borderColor = 'var(--border-strong)';
    el.style.transform = 'scale(1.015) translateY(-3px)';
    el.style.boxShadow = 'var(--shadow-md)';
  }, []);

  const handleMouseLeave = React.useCallback((e) => {
    const el = ref.current;
    if (!el) return;
    el.style.borderColor = 'var(--border)';
    el.style.transform = '';
    el.style.boxShadow = 'none';
    el.style.setProperty('--mouse-x', '50%');
    el.style.setProperty('--mouse-y', '50%');
  }, []);

  const baseStyle = {
    '--mouse-x': '50%',
    '--mouse-y': '50%',
    position: 'relative',
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    padding: padding ?? 'var(--card-pad)',
    overflow: 'hidden',
    transition: 'transform 200ms cubic-bezier(.4,0,.2,1), box-shadow 200ms cubic-bezier(.4,0,.2,1), border-color 120ms cubic-bezier(.4,0,.2,1)',
    cursor: href ? 'pointer' : 'default',
    textDecoration: 'none',
    color: 'inherit',
    display: 'block',
    ...style,
  };

  const spotlightStyle = {
    content: '""',
    position: 'absolute',
    inset: 0,
    background: 'radial-gradient(400px circle at var(--mouse-x) var(--mouse-y), var(--spotlight), transparent 70%)',
    opacity: 0,
    transition: 'opacity 300ms',
    pointerEvents: 'none',
    borderRadius: 'inherit',
    zIndex: 0,
  };

  const element = href ? 'a' : as;

  return React.createElement(element, {
    ref,
    href,
    style: baseStyle,
    onMouseMove: handleMouseMove,
    onMouseEnter: handleMouseEnter,
    onMouseLeave: handleMouseLeave,
    ...rest,
  },
    React.createElement('div', {
      'aria-hidden': 'true',
      style: { ...spotlightStyle, opacity: 1 },
    }),
    React.createElement('div', { style: { position: 'relative', zIndex: 1 } }, children)
  );
}

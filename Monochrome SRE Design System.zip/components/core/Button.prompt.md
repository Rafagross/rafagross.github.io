Primary call-to-action button with three visual weight variants and three sizes.

```jsx
<Button variant="primary">Deploy</Button>
<Button variant="secondary" size="sm">View Runbook</Button>
<Button variant="ghost" href="/resume">Resume ↗</Button>
<Button variant="primary" disabled>Unavailable</Button>
```

Notable props: `variant` (primary/secondary/ghost), `size` (sm/md/lg), `href` (renders as `<a>`), `disabled`.

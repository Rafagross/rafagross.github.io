Pulsing green dot — the only non-grayscale element in the system.

```jsx
<StatusDot />
<StatusDot label="Open to contract work" />
```

The pulse animation is a subtle opacity+scale keyframe (2.4s loop).
Respects prefers-reduced-motion. Injects its own <style> tag once.

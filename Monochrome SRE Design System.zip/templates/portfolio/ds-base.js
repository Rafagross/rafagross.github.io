// templates/portfolio/ds-base.js
// Loads the Monochrome SRE Design System tokens + component bundle.
// Edit `base` if this template is nested deeper than one level from the project root.

(() => {
  const base = '../..'; // path to project root relative to this file

  // 1. Inject global stylesheet (tokens, fonts)
  for (const p of ['styles.css']) {
    const l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = base + '/' + p;
    document.head.appendChild(l);
  }

  // 2. Inject compiled component bundle
  const s = document.createElement('script');
  s.src = base + '/_ds_bundle.js';
  s.onerror = () => console.error(
    'ds-base.js: failed to load ' + s.src +
    ' — if the bundle is not compiled yet, open the design system project first. ' +
    'If this template is nested differently, update the `base` variable in this file.'
  );
  document.head.appendChild(s);
})();

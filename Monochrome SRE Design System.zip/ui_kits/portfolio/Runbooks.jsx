/* Runbooks.jsx — collapsible runbook cards with severity badges */

const T_RUN = {
  en: { heading: 'Runbooks', sub: 'Field-tested operational procedures', expand: 'Expand', collapse: 'Collapse' },
  es: { heading: 'Runbooks', sub: 'Procedimientos operativos probados en campo', expand: 'Expandir', collapse: 'Colapsar' },
};

const RUNBOOKS = [
  {
    title: 'EC2 Instance Unreachable via SSM Session Manager',
    severity: 'P2',
    status: 'stable',
    time: '~15 min',
    tags: ['AWS','EC2','SSM','CloudWatch','IAM'],
    desc: 'Systematic triage for EC2 instances that fail to register with SSM. Covers IAM role misconfiguration, missing SSM agent, VPC endpoint routing, and network ACL issues.',
    steps: [
      'Verify instance profile has AmazonSSMManagedInstanceCore policy attached.',
      'Check SSM agent status: aws ssm describe-instance-information --filters "Key=InstanceIds,Values=i-xxxx"',
      'Inspect CloudWatch agent logs at /var/log/amazon/ssm/amazon-ssm-agent.log',
      'Confirm VPC has com.amazonaws.<region>.ssm endpoint or NAT gateway for outbound access.',
      'Validate security group allows HTTPS (443) outbound to SSM endpoints.',
      'If instance was recently patched, verify agent was not removed during cleanup.',
    ],
  },
  {
    title: 'Kubernetes Node NotReady — Systematic Recovery',
    severity: 'P3',
    status: 'stable',
    time: '~10 min',
    tags: ['Kubernetes','kubectl','kubelet','containerd'],
    desc: 'Step-by-step recovery for nodes stuck in NotReady state. Covers kubelet failures, disk pressure, network plugin issues, and certificate rotation edge cases.',
    steps: [
      'Describe the node: kubectl describe node <node-name> — check Conditions and Events.',
      'SSH into the node and verify kubelet: systemctl status kubelet',
      'Check logs: journalctl -u kubelet --no-pager -n 100',
      'Inspect disk pressure: df -h and check /var/lib/kubelet and /var/lib/containerd.',
      'Verify CNI plugin is running: ls /etc/cni/net.d/ and check plugin pod status.',
      'If cert issue: kubeadm certs check-expiration and rotate as needed.',
    ],
  },
];

function Runbooks({ lang }) {
  const t = T_RUN[lang];
  return (
    <section id="runbooks" style={{
      padding: 'var(--section-gap) clamp(20px,4vw,48px)',
      background: 'var(--bg-subtle)',
      borderTop: '1px solid var(--border)',
      borderBottom: '1px solid var(--border)',
    }}>
      <div style={{ maxWidth: 'var(--max-width)', margin: '0 auto' }}>
        <window.SectionHeader label="02" heading={t.heading} sub={t.sub} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {RUNBOOKS.map((rb, i) => (
            <RunbookCard key={rb.title} runbook={rb} t={t} idx={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function RunbookCard({ runbook, t, idx }) {
  const [open, setOpen] = React.useState(false);
  const [hov, setHov] = React.useState(false);

  return (
    <div
      className="fade-in"
      style={{
        background: 'var(--surface)', border: '1px solid',
        borderColor: hov || open ? 'var(--border-strong)' : 'var(--border)',
        borderRadius: 'var(--radius)', overflow: 'hidden',
        transition: 'border-color 120ms cubic-bezier(.4,0,.2,1)',
      }}
      onMouseEnter={()=>setHov(true)}
      onMouseLeave={()=>setHov(false)}
    >
      {/* Header row — always visible */}
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 16,
          padding: '18px 24px', background: 'transparent', border: 'none',
          cursor: 'pointer', textAlign: 'left',
        }}
      >
        {/* Severity badge */}
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700,
          letterSpacing: '0.12em', textTransform: 'uppercase',
          color: 'var(--text)', border: '1px solid var(--border-strong)',
          borderRadius: 'var(--radius-sm)', padding: '3px 8px',
          background: 'var(--bg-subtle)', flexShrink: 0,
        }}>{runbook.severity}</span>

        {/* Title */}
        <span style={{
          fontFamily: 'var(--font-sans)', fontWeight: 600,
          fontSize: 'var(--text-base)', letterSpacing: 'var(--tracking-tight)',
          color: 'var(--text)', flex: 1, lineHeight: 'var(--leading-snug)',
        }}>{runbook.title}</span>

        {/* Meta */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-faint)', letterSpacing: '0.04em' }}>
            {runbook.time}
          </span>
          <span style={{
            fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 600,
            letterSpacing: '0.12em', textTransform: 'uppercase',
            color: 'var(--text-muted)', border: '1px solid var(--border)',
            borderRadius: 'var(--radius-sm)', padding: '2px 7px',
          }}>{runbook.status}</span>
          {/* Chevron */}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"
            style={{ color: 'var(--text-faint)', transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 200ms cubic-bezier(.4,0,.2,1)' }}>
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </div>
      </button>

      {/* Tags row — always visible */}
      <div style={{ padding: '0 24px 16px', display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {runbook.tags.map(tag => (
          <span key={tag} style={{
            fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 500,
            letterSpacing: '0.06em', textTransform: 'uppercase',
            color: 'var(--text-faint)', background: 'var(--bg-subtle)',
            border: '1px solid var(--border)', borderRadius: 9999,
            padding: '2px 8px',
          }}>{tag}</span>
        ))}
      </div>

      {/* Expandable content */}
      <div style={{
        maxHeight: open ? '800px' : '0',
        overflow: 'hidden',
        transition: 'max-height 320ms cubic-bezier(.4,0,.2,1)',
      }}>
        <div style={{
          padding: '0 24px 24px',
          borderTop: '1px solid var(--border)',
          paddingTop: 20,
        }}>
          <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', lineHeight: 'var(--leading-normal)', marginBottom: 20 }}>
            {runbook.desc}
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {runbook.steps.map((step, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <span style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-faint)',
                  flexShrink: 0, paddingTop: 2, minWidth: 20,
                }}>{String(i+1).padStart(2,'0')}</span>
                <p style={{
                  fontSize: 'var(--text-sm)', color: 'var(--text-muted)',
                  lineHeight: 'var(--leading-normal)', fontFamily: step.startsWith('aws ') || step.startsWith('kubectl') || step.startsWith('systemctl') || step.startsWith('journalctl') || step.startsWith('kubeadm') ? 'var(--font-mono)' : 'inherit',
                  fontSize: step.startsWith('aws ') || step.startsWith('kubectl') || step.startsWith('systemctl') || step.startsWith('journalctl') || step.startsWith('kubeadm') ? 12 : 'var(--text-sm)',
                }}>{step}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

window.Runbooks = Runbooks;

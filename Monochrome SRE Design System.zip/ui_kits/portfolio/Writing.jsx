/* Writing.jsx — technical notes section */

const T_WRITE = {
  en: { heading: 'Writing', sub: 'Technical notes and field observations', read: 'Read →' },
  es: { heading: 'Escritura', sub: 'Notas técnicas y observaciones de campo', read: 'Leer →' },
};

const POSTS = [
  {
    title: 'Running k3s on Proxmox: A Production-Grade Homelab',
    category: 'Infrastructure',
    date: 'Jan 2025',
    desc: 'How I set up a lightweight Kubernetes cluster on Proxmox VE using k3s, Terraform for VM provisioning, and Flux CD for GitOps-driven deployments. Covers storage, networking, and observability.',
    href: '#',
  },
  {
    title: 'EC2 Golden AMI Pipelines with Packer and AWS Image Builder',
    category: 'AWS',
    date: 'Nov 2024',
    desc: 'A walkthrough of building hardened, pre-patched AMIs that comply with CIS benchmarks. Covers pipeline architecture, testing gates, automated distribution, and integration with AWS Systems Manager.',
    href: '#',
  },
];

function Writing({ lang }) {
  const t = T_WRITE[lang];
  return (
    <section id="writing" style={{
      padding: 'var(--section-gap) clamp(20px,4vw,48px)',
      background: 'var(--bg)',
    }}>
      <div style={{ maxWidth: 'var(--max-width)', margin: '0 auto' }}>
        <window.SectionHeader label="03" heading={t.heading} sub={t.sub} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {POSTS.map((post, i) => (
            <WritingRow key={post.title} post={post} read={t.read} idx={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function WritingRow({ post, read, idx }) {
  const [hov, setHov] = React.useState(false);
  return (
    <a
      href={post.href}
      className="fade-in"
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 24,
        padding: '24px 0', textDecoration: 'none', color: 'inherit',
        borderBottom: '1px solid var(--border)',
        transition: 'opacity var(--duration-fast) var(--ease-default)',
        opacity: hov ? 1 : 0.92,
      }}
      onMouseEnter={()=>setHov(true)}
      onMouseLeave={()=>setHov(false)}
    >
      {/* Date + category */}
      <div style={{ flexShrink: 0, width: 120, paddingTop: 2 }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-faint)', letterSpacing: '0.06em', marginBottom: 4 }}>
          {post.date}
        </div>
        <div style={{
          display: 'inline-block',
          fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 600,
          letterSpacing: '0.12em', textTransform: 'uppercase',
          color: 'var(--text-muted)', border: '1px solid var(--border)',
          borderRadius: 9999, padding: '2px 8px',
        }}>{post.category}</div>
      </div>

      {/* Content */}
      <div style={{ flex: 1 }}>
        <h3 style={{
          fontFamily: 'var(--font-sans)', fontWeight: 600,
          fontSize: 'var(--text-base)', letterSpacing: 'var(--tracking-tight)',
          color: 'var(--text)', lineHeight: 'var(--leading-snug)', marginBottom: 8,
        }}>{post.title}</h3>
        <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', lineHeight: 'var(--leading-normal)' }}>
          {post.desc}
        </p>
      </div>

      {/* Arrow */}
      <div style={{
        flexShrink: 0, fontFamily: 'var(--font-mono)', fontSize: 12,
        color: hov ? 'var(--text)' : 'var(--text-faint)',
        transition: 'color var(--duration-fast) var(--ease-default), transform var(--duration-fast) var(--ease-default)',
        transform: hov ? 'translateX(4px)' : 'none',
        paddingTop: 2,
      }}>{read}</div>
    </a>
  );
}

window.Writing = Writing;

/* Projects.jsx — 3 project cards with spotlight hover effect */

const T_PROJ = {
  en: { heading: 'Projects', sub: 'Selected infrastructure work', ext: 'View ↗' },
  es: { heading: 'Proyectos', sub: 'Trabajo de infraestructura seleccionado', ext: 'Ver ↗' },
};

const PROJECTS = [
  {
    title: 'AWS CloudOps Private EC2 Operations Platform',
    desc: 'Private, policy-driven platform for managing EC2 fleets at scale. Covers patch management, compliance automation, and incident response via AWS Systems Manager.',
    tags: ['AWS','EC2','SSM','CloudWatch','Bash','Patch Management'],
    badge: 'Featured',
    status: 'active',
    href: '#',
  },
  {
    title: 'Kubernetes Homelab Platform',
    desc: 'Production-grade k3s cluster on Proxmox. GitOps-driven manifests, Terraform-provisioned infrastructure, and full observability stack with Grafana and Prometheus.',
    tags: ['Kubernetes','k3s','Terraform','Proxmox','GitOps'],
    badge: null,
    status: 'active',
    href: '#',
  },
  {
    title: 'AWS CloudWatch Observability Stack',
    desc: 'Unified observability layer across multi-account AWS environments — custom dashboards, composite alarms, log insights queries, and PagerDuty integration.',
    tags: ['CloudWatch','AWS','Terraform','Bash','SNS'],
    badge: null,
    status: 'active',
    href: '#',
  },
];

function Projects({ lang }) {
  const t = T_PROJ[lang];
  return (
    <section id="projects" style={{
      padding: 'var(--section-gap) clamp(20px,4vw,48px)',
      background: 'var(--bg)',
    }}>
      <div style={{ maxWidth: 'var(--max-width)', margin: '0 auto' }}>
        <SectionHeader label="01" heading={t.heading} sub={t.sub} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
          {PROJECTS.map((p, i) => (
            <ProjectCard key={p.title} project={p} ext={t.ext} idx={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({ project, ext, idx }) {
  const cardRef = React.useRef(null);
  const [hov, setHov] = React.useState(false);

  const onMouseMove = (e) => {
    const el = cardRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', ((e.clientX-r.left)/r.width*100)+'%');
    el.style.setProperty('--my', ((e.clientY-r.top)/r.height*100)+'%');
  };

  return (
    <a ref={cardRef} href={project.href}
      className="fade-in"
      onMouseMove={onMouseMove}
      onMouseEnter={()=>setHov(true)}
      onMouseLeave={()=>setHov(false)}
      style={{
        '--mx':'50%','--my':'50%',
        position:'relative', overflow:'hidden',
        display:'block', textDecoration:'none', color:'inherit',
        background:'var(--surface)', border:'1px solid',
        borderColor: hov ? 'var(--border-strong)' : 'var(--border)',
        borderRadius:'var(--radius)', padding:'var(--card-pad)',
        transform: hov ? 'scale(1.015) translateY(-3px)' : 'none',
        boxShadow: hov ? 'var(--shadow-md)' : 'none',
        transition:'transform 200ms cubic-bezier(.4,0,.2,1), box-shadow 200ms cubic-bezier(.4,0,.2,1), border-color 120ms cubic-bezier(.4,0,.2,1)',
      }}>
      {/* Spotlight */}
      <div aria-hidden="true" style={{
        position:'absolute', inset:0, pointerEvents:'none', zIndex:0, borderRadius:'inherit',
        background:'radial-gradient(380px circle at var(--mx) var(--my), var(--spotlight), transparent 70%)',
      }}/>
      <div style={{ position:'relative', zIndex:1, display:'flex', flexDirection:'column', height:'100%', gap:16 }}>
        {/* Top row */}
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:8 }}>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
            {project.badge && (
              <span style={{
                fontFamily:'var(--font-mono)', fontSize:10, fontWeight:700,
                letterSpacing:'0.14em', textTransform:'uppercase',
                color:'var(--accent)', border:'1px solid var(--accent)',
                borderRadius:'var(--radius-sm)', padding:'2px 7px',
              }}>{project.badge}</span>
            )}
            <span style={{
              fontFamily:'var(--font-mono)', fontSize:10, fontWeight:600,
              letterSpacing:'0.14em', textTransform:'uppercase',
              color:'var(--text-muted)', border:'1px solid var(--border)',
              borderRadius:'var(--radius-sm)', padding:'2px 7px',
            }}>{project.status}</span>
          </div>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ color:'var(--text-faint)', flexShrink:0, marginTop:1 }}>
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
          </svg>
        </div>
        {/* Title */}
        <h3 style={{
          fontFamily:'var(--font-sans)', fontWeight:600,
          fontSize:'var(--text-base)', letterSpacing:'var(--tracking-tight)',
          color:'var(--text)', lineHeight:'var(--leading-snug)', flex:1,
        }}>{project.title}</h3>
        {/* Desc */}
        <p style={{ fontSize:'var(--text-sm)', color:'var(--text-muted)', lineHeight:'var(--leading-normal)', marginBottom:8 }}>
          {project.desc}
        </p>
        {/* Tags */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
          {project.tags.map(tag => (
            <span key={tag} style={{
              fontFamily:'var(--font-mono)', fontSize:10, fontWeight:500,
              letterSpacing:'0.06em', textTransform:'uppercase',
              color:'var(--text-faint)', background:'var(--bg-subtle)',
              border:'1px solid var(--border)', borderRadius:9999,
              padding:'2px 8px',
            }}>{tag}</span>
          ))}
        </div>
      </div>
    </a>
  );
}

function SectionHeader({ label, heading, sub }) {
  return (
    <div style={{ marginBottom: 36 }}>
      <span style={{
        fontFamily:'var(--font-mono)', fontSize:10, letterSpacing:'0.16em',
        textTransform:'uppercase', color:'var(--text-faint)', display:'block', marginBottom:8,
      }}>{label}</span>
      <h2 style={{
        fontFamily:'var(--font-display)', fontWeight:700,
        fontSize:'var(--text-h2)', letterSpacing:'var(--tracking-tight)',
        color:'var(--text)', lineHeight:'var(--leading-tight)', marginBottom:6,
      }}>{heading}</h2>
      <p style={{ fontSize:'var(--text-sm)', color:'var(--text-muted)' }}>{sub}</p>
    </div>
  );
}

window.Projects = Projects;
window.SectionHeader = SectionHeader;

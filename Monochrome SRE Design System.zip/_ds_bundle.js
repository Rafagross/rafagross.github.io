/* @ds-bundle: {"format":3,"namespace":"MonochromeSREDesignSystem_10ba68","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"NavLink","sourcePath":"components/core/NavLink.jsx"},{"name":"StatusDot","sourcePath":"components/core/StatusDot.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"ThemeToggle","sourcePath":"components/core/ThemeToggle.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"a66345bf8a81","components/core/Button.jsx":"f7c43fecc0e4","components/core/Card.jsx":"5ce83939735a","components/core/NavLink.jsx":"d362cc6e330f","components/core/StatusDot.jsx":"897e9176e120","components/core/Tag.jsx":"7c93af0f59e2","components/core/ThemeToggle.jsx":"ef3f2cc66aae","ui_kits/portfolio/Footer.jsx":"4684bd78317c","ui_kits/portfolio/Hero.jsx":"598079f468ec","ui_kits/portfolio/Nav.jsx":"9383a6881691","ui_kits/portfolio/Projects.jsx":"bcd703ee1856","ui_kits/portfolio/Runbooks.jsx":"3ca2380a9056","ui_kits/portfolio/Terminal.jsx":"e7d7e2a702b6","ui_kits/portfolio/Writing.jsx":"c7481c6731f0","ui_kits/portfolio/tweaks-panel.jsx":"6591467622ed"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MonochromeSREDesignSystem_10ba68 = window.MonochromeSREDesignSystem_10ba68 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
/**
 * Badge — monospaced label for severity, status, and classification.
 * Used in runbook cards (P2/P3) and project cards (Featured/Active).
 *
 * @example
 * <Badge variant="severity" level="P2">P2</Badge>
 * <Badge variant="status" status="stable">stable</Badge>
 * <Badge variant="featured">Featured</Badge>
 */

function Badge({
  variant = 'default',
  level,
  status,
  children,
  style
}) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '5px',
    fontFamily: 'var(--font-mono)',
    fontSize: 'var(--text-2xs)',
    fontWeight: 'var(--fw-semibold)',
    letterSpacing: 'var(--tracking-label)',
    textTransform: 'uppercase',
    borderRadius: 'var(--radius-sm)',
    padding: '3px 8px',
    border: '1px solid',
    lineHeight: 1.4,
    whiteSpace: 'nowrap'
  };
  const severityStyles = {
    P1: {
      color: 'var(--text)',
      borderColor: 'var(--border-strong)',
      background: 'var(--surface-raised)'
    },
    P2: {
      color: 'var(--text)',
      borderColor: 'var(--border-strong)',
      background: 'var(--surface-raised)'
    },
    P3: {
      color: 'var(--text-muted)',
      borderColor: 'var(--border)',
      background: 'transparent'
    }
  };
  const variants = {
    default: {
      color: 'var(--text-muted)',
      borderColor: 'var(--border)',
      background: 'transparent'
    },
    featured: {
      color: 'var(--accent)',
      borderColor: 'var(--accent)',
      background: 'transparent'
    },
    active: {
      color: 'var(--text)',
      borderColor: 'var(--border-strong)',
      background: 'var(--surface-raised)'
    },
    stable: {
      color: 'var(--text-muted)',
      borderColor: 'var(--border)',
      background: 'transparent'
    },
    severity: severityStyles[level] || severityStyles.P3,
    status: {
      color: 'var(--text-muted)',
      borderColor: 'var(--border)',
      background: 'transparent'
    }
  };
  const chosen = variants[variant] || variants.default;
  return React.createElement('span', {
    style: {
      ...base,
      ...chosen,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
/**
 * Button — primary interactive element. Variants: primary, secondary, ghost.
 *
 * @example
 * <Button variant="primary">Deploy</Button>
 * <Button variant="secondary" size="sm">View Runbook</Button>
 * <Button variant="ghost" href="/resume">Resume ↗</Button>
 */

function Button({
  variant = 'primary',
  size = 'md',
  href,
  disabled,
  children,
  onClick,
  style,
  ...rest
}) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '6px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-medium)',
    letterSpacing: 'var(--tracking-tight)',
    border: '1px solid transparent',
    borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    textDecoration: 'none',
    transition: 'background-color var(--duration-fast) var(--ease-default), color var(--duration-fast) var(--ease-default), border-color var(--duration-fast) var(--ease-default), transform var(--duration-fast) var(--ease-default)',
    outline: 'none',
    userSelect: 'none',
    whiteSpace: 'nowrap'
  };
  const sizes = {
    sm: {
      fontSize: 'var(--text-xs)',
      padding: '5px 12px',
      lineHeight: 1
    },
    md: {
      fontSize: 'var(--text-sm)',
      padding: '8px 18px',
      lineHeight: 1
    },
    lg: {
      fontSize: 'var(--text-base)',
      padding: '11px 24px',
      lineHeight: 1
    }
  };
  const variants = {
    primary: {
      background: 'var(--accent)',
      color: 'var(--accent-text)',
      borderColor: 'var(--accent)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--text)',
      borderColor: 'var(--border-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-muted)',
      borderColor: 'transparent'
    }
  };
  const combinedStyle = {
    ...base,
    ...sizes[size],
    ...variants[variant],
    ...style
  };
  const handleMouseEnter = e => {
    if (disabled) return;
    if (variant === 'primary') {
      e.currentTarget.style.opacity = '0.85';
      e.currentTarget.style.transform = 'translateY(-1px)';
    } else if (variant === 'secondary') {
      e.currentTarget.style.borderColor = 'var(--text)';
      e.currentTarget.style.transform = 'translateY(-1px)';
    } else {
      e.currentTarget.style.color = 'var(--text)';
    }
  };
  const handleMouseLeave = e => {
    if (disabled) return;
    e.currentTarget.style.opacity = variant === 'primary' ? '1' : '1';
    e.currentTarget.style.transform = '';
    e.currentTarget.style.borderColor = variants[variant].borderColor;
    e.currentTarget.style.color = variants[variant].color;
  };
  const props = {
    style: combinedStyle,
    disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: handleMouseEnter,
    onMouseLeave: handleMouseLeave,
    onFocus: e => {
      e.currentTarget.style.outline = '2px solid var(--accent)';
      e.currentTarget.style.outlineOffset = '3px';
    },
    onBlur: e => {
      e.currentTarget.style.outline = 'none';
    },
    ...rest
  };
  if (href) {
    return React.createElement('a', {
      href,
      ...props
    }, children);
  }
  return React.createElement('button', {
    type: 'button',
    ...props
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
/**
 * Card — base surface with spotlight hover effect.
 * Hover: border strengthens, card lifts, a radial spotlight follows the mouse.
 *
 * @example
 * <Card>Content here</Card>
 * <Card as="a" href="/projects/foo">Linked card</Card>
 */

function Card({
  as = 'div',
  href,
  children,
  style,
  padding,
  ...rest
}) {
  const ref = React.useRef(null);
  const handleMouseMove = React.useCallback(e => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width * 100;
    const y = (e.clientY - rect.top) / rect.height * 100;
    el.style.setProperty('--mouse-x', x + '%');
    el.style.setProperty('--mouse-y', y + '%');
  }, []);
  const handleMouseEnter = React.useCallback(e => {
    const el = ref.current;
    if (!el) return;
    el.style.borderColor = 'var(--border-strong)';
    el.style.transform = 'scale(1.015) translateY(-3px)';
    el.style.boxShadow = 'var(--shadow-md)';
  }, []);
  const handleMouseLeave = React.useCallback(e => {
    const el = ref.current;
    if (!el) return;
    el.style.borderColor = 'var(--border)';
    el.style.transform = '';
    el.style.boxShadow = 'none';
    el.style.setProperty('--mouse-x', '50%');
    el.style.setProperty('--mouse-y', '50%');
  }, []);
  const baseStyle = {
    '--mouse-x': '50%',
    '--mouse-y': '50%',
    position: 'relative',
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    padding: padding ?? 'var(--card-pad)',
    overflow: 'hidden',
    transition: 'transform 200ms cubic-bezier(.4,0,.2,1), box-shadow 200ms cubic-bezier(.4,0,.2,1), border-color 120ms cubic-bezier(.4,0,.2,1)',
    cursor: href ? 'pointer' : 'default',
    textDecoration: 'none',
    color: 'inherit',
    display: 'block',
    ...style
  };
  const spotlightStyle = {
    content: '""',
    position: 'absolute',
    inset: 0,
    background: 'radial-gradient(400px circle at var(--mouse-x) var(--mouse-y), var(--spotlight), transparent 70%)',
    opacity: 0,
    transition: 'opacity 300ms',
    pointerEvents: 'none',
    borderRadius: 'inherit',
    zIndex: 0
  };
  const element = href ? 'a' : as;
  return React.createElement(element, {
    ref,
    href,
    style: baseStyle,
    onMouseMove: handleMouseMove,
    onMouseEnter: handleMouseEnter,
    onMouseLeave: handleMouseLeave,
    ...rest
  }, React.createElement('div', {
    'aria-hidden': 'true',
    style: {
      ...spotlightStyle,
      opacity: 1
    }
  }), React.createElement('div', {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/NavLink.jsx
try { (() => {
/**
 * NavLink — navigation anchor with animated underline on hover/active.
 *
 * @example
 * <NavLink href="#projects">Projects</NavLink>
 * <NavLink href="#runbooks" active>Runbooks</NavLink>
 */

function NavLink({
  href,
  active,
  children,
  style
}) {
  const [hovered, setHovered] = React.useState(false);
  return React.createElement('a', {
    href,
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--fw-medium)',
      color: active || hovered ? 'var(--text)' : 'var(--text-muted)',
      textDecoration: 'none',
      letterSpacing: 'var(--tracking-tight)',
      padding: '4px 0',
      transition: 'color var(--duration-fast) var(--ease-default)',
      outline: 'none',
      ...style
    },
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    onFocus: e => {
      setHovered(true);
      e.currentTarget.style.outline = '2px solid var(--accent)';
      e.currentTarget.style.outlineOffset = '4px';
    },
    onBlur: e => {
      setHovered(false);
      e.currentTarget.style.outline = 'none';
    }
  }, children, React.createElement('span', {
    'aria-hidden': 'true',
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      width: active || hovered ? '100%' : '0%',
      height: '1px',
      background: 'var(--accent)',
      transition: 'width var(--duration-normal) var(--ease-default)'
    }
  }));
}
Object.assign(__ds_scope, { NavLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/NavLink.jsx", error: String((e && e.message) || e) }); }

// components/core/StatusDot.jsx
try { (() => {
/**
 * StatusDot — animated green "Available" indicator.
 * The ONLY element in the system that uses a non-grayscale color.
 *
 * @example
 * <StatusDot /> Available for new roles
 */

function StatusDot({
  label = 'Available for new roles',
  style
}) {
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '8px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-muted)',
      letterSpacing: '0.04em',
      ...style
    }
  }, React.createElement('span', {
    style: {
      position: 'relative',
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      background: 'var(--green)',
      flexShrink: 0,
      display: 'inline-block'
    }
  }, React.createElement('span', {
    style: {
      position: 'absolute',
      inset: '-3px',
      borderRadius: '50%',
      background: 'var(--green)',
      opacity: 0,
      animation: 'status-pulse 2.4s cubic-bezier(.4,0,.6,1) infinite'
    }
  })), label);
}

// Inject keyframes once
if (typeof document !== 'undefined' && !document.getElementById('status-dot-style')) {
  const s = document.createElement('style');
  s.id = 'status-dot-style';
  s.textContent = `
    @keyframes status-pulse {
      0%, 100% { opacity: 0; transform: scale(1); }
      50% { opacity: 0.35; transform: scale(2.2); }
    }
    @media (prefers-reduced-motion: reduce) {
      @keyframes status-pulse { 0%, 100% { opacity: 0; } }
    }
  `;
  document.head.appendChild(s);
}
Object.assign(__ds_scope, { StatusDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatusDot.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
/**
 * Tag — tech-stack label. Small, monospaced, uppercase pill.
 * Used in project cards and runbook metadata.
 *
 * @example
 * <Tag>AWS</Tag>
 * <Tag>Kubernetes</Tag>
 * <Tag>Terraform</Tag>
 */

function Tag({
  children,
  style
}) {
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: '11px',
      fontWeight: 'var(--fw-medium)',
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      background: 'var(--bg-subtle)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-full)',
      padding: '3px 9px',
      lineHeight: 1.4,
      whiteSpace: 'nowrap',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/core/ThemeToggle.jsx
try { (() => {
/**
 * ThemeToggle — sun/moon icon button to switch light ↔ dark theme.
 * Reads/writes data-theme on <html>. Persists to localStorage.
 *
 * @example
 * <ThemeToggle />
 */

function ThemeToggle({
  style
}) {
  const [isDark, setIsDark] = React.useState(() => {
    if (typeof document === 'undefined') return false;
    return document.documentElement.getAttribute('data-theme') === 'dark';
  });
  const toggle = () => {
    const next = isDark ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try {
      localStorage.setItem('sre-theme', next);
    } catch {}
    setIsDark(!isDark);
  };
  const [hovered, setHovered] = React.useState(false);

  // Sun icon (light mode indicator)
  const SunIcon = React.createElement('svg', {
    width: 16,
    height: 16,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.5,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': 'true'
  }, React.createElement('circle', {
    cx: 12,
    cy: 12,
    r: 5
  }), React.createElement('line', {
    x1: 12,
    y1: 1,
    x2: 12,
    y2: 3
  }), React.createElement('line', {
    x1: 12,
    y1: 21,
    x2: 12,
    y2: 23
  }), React.createElement('line', {
    x1: 4.22,
    y1: 4.22,
    x2: 5.64,
    y2: 5.64
  }), React.createElement('line', {
    x1: 18.36,
    y1: 18.36,
    x2: 19.78,
    y2: 19.78
  }), React.createElement('line', {
    x1: 1,
    y1: 12,
    x2: 3,
    y2: 12
  }), React.createElement('line', {
    x1: 21,
    y1: 12,
    x2: 23,
    y2: 12
  }), React.createElement('line', {
    x1: 4.22,
    y1: 19.78,
    x2: 5.64,
    y2: 18.36
  }), React.createElement('line', {
    x1: 18.36,
    y1: 5.64,
    x2: 19.78,
    y2: 4.22
  }));

  // Moon icon (dark mode indicator)
  const MoonIcon = React.createElement('svg', {
    width: 16,
    height: 16,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.5,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': 'true'
  }, React.createElement('path', {
    d: 'M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z'
  }));
  return React.createElement('button', {
    type: 'button',
    'aria-label': isDark ? 'Switch to light mode' : 'Switch to dark mode',
    onClick: toggle,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    onFocus: e => {
      e.currentTarget.style.outline = '2px solid var(--accent)';
      e.currentTarget.style.outlineOffset = '3px';
    },
    onBlur: e => {
      e.currentTarget.style.outline = 'none';
    },
    style: {
      background: 'transparent',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      color: hovered ? 'var(--text)' : 'var(--text-muted)',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: '34px',
      height: '34px',
      padding: 0,
      transition: 'color var(--duration-fast) var(--ease-default), border-color var(--duration-fast) var(--ease-default)',
      borderColor: hovered ? 'var(--border-strong)' : 'var(--border)',
      outline: 'none',
      flexShrink: 0,
      ...style
    }
  }, isDark ? SunIcon : MoonIcon);
}
Object.assign(__ds_scope, { ThemeToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ThemeToggle.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Footer.jsx
try { (() => {
/* Footer.jsx — minimal footer */

const T_FOOT = {
  en: {
    built: 'Designed and built by Elvis Rafael Gross.',
    role: 'CloudOps · Platform · SRE',
    links: ['GitHub', 'LinkedIn', 'Email']
  },
  es: {
    built: 'Diseñado y construido por Elvis Rafael Gross.',
    role: 'CloudOps · Plataforma · SRE',
    links: ['GitHub', 'LinkedIn', 'Correo']
  }
};
const LINK_HREFS = ['https://github.com', 'https://linkedin.com', 'mailto:hello@elvisrafaelgross.com'];
function Footer({
  lang
}) {
  const t = T_FOOT[lang];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border)',
      padding: 'clamp(40px,6vw,64px) clamp(20px,4vw,48px)',
      background: 'var(--bg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max-width)',
      margin: '0 auto',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text)',
      marginBottom: 6
    }
  }, "ERG"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, t.built), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-faint)',
      marginTop: 4,
      letterSpacing: '0.06em'
    }
  }, t.role)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 24,
      alignItems: 'center'
    }
  }, t.links.map((label, i) => /*#__PURE__*/React.createElement(FooterLink, {
    key: label,
    href: LINK_HREFS[i]
  }, label)))));
}
function FooterLink({
  href,
  children
}) {
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500,
      color: hov ? 'var(--text)' : 'var(--text-muted)',
      textDecoration: 'none',
      transition: 'color var(--duration-fast) var(--ease-default)'
    },
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false)
  }, children);
}
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Hero.jsx
try { (() => {
/* Hero.jsx — white-only flow-field + SVG cloud icon (DOM) with full-outline glow */

const T_HERO = {
  en: {
    available: 'Available for new roles',
    roles: ['CloudOps Engineer', 'Platform Engineer', 'SRE'],
    name: ['Elvis Rafael', 'Gross'],
    pitch: 'I build and operate cloud infrastructure at scale — AWS EC2 fleets, Kubernetes platforms, hybrid architectures, and the observability that keeps them running.',
    cta1: 'View Projects',
    cta2: 'Resume \u2197',
    tagline: 'Stack'
  },
  es: {
    available: 'Disponible para nuevas oportunidades',
    roles: ['Ingeniero CloudOps', 'Ingeniero de Plataforma', 'SRE'],
    name: ['Elvis Rafael', 'Gross'],
    pitch: 'Construyo y opero infraestructura cloud a escala \u2014 flotas EC2 de AWS, plataformas Kubernetes, arquitecturas h\u00edbridas y la observabilidad que las mantiene en marcha.',
    cta1: 'Ver Proyectos',
    cta2: 'Curr\u00edculum \u2197',
    tagline: 'Stack'
  }
};
const STACK = ['AWS', 'GCP', 'Terraform', 'Kubernetes', 'Golden AMI Pipelines', 'CloudWatch', 'Bash', 'AWS Systems Manager', 'AWS CLI', 'Patch Management'];

/* =================================================================
   FlowFieldCanvas — white-only particles, slow speed
   ================================================================= */
function FlowFieldCanvas() {
  var canvasRef = React.useRef(null);
  React.useEffect(function () {
    var canvas = canvasRef.current;
    if (!canvas) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var ctx = canvas.getContext('2d');
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W, H, raf;
    var N = 180,
      LIFE = 200,
      SPD = 0.55,
      FFS = 0.0032;
    var particles = [];
    function resize() {
      W = canvas.offsetWidth;
      H = canvas.offsetHeight;
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      particles = [];
      for (var i = 0; i < N; i++) particles.push({
        x: Math.random() * W,
        y: Math.random() * H,
        age: Math.floor(Math.random() * LIFE)
      });
    }
    var ro = new ResizeObserver(resize);
    ro.observe(canvas);
    resize();
    var t = 0;
    function frame() {
      var dark = document.documentElement.getAttribute('data-theme') === 'dark';
      var bgRgb = dark ? '11,11,11' : '255,255,255';
      var pMax = dark ? 0.22 : 0.09;
      ctx.fillStyle = 'rgba(' + bgRgb + ',0.04)';
      ctx.fillRect(0, 0, W, H);
      ctx.lineWidth = 0.65;
      for (var i = 0; i < particles.length; i++) {
        var p = particles[i];
        var ang = Math.sin(p.x * FFS + t * 0.14) * Math.PI + Math.cos(p.y * FFS + t * 0.10) * Math.PI;
        var nx = p.x + Math.cos(ang) * SPD,
          ny = p.y + Math.sin(ang) * SPD;
        var a = Math.min(p.age / 36, (LIFE - p.age) / 36, 1) * pMax;
        ctx.strokeStyle = 'rgba(255,255,255,' + a + ')';
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(nx, ny);
        ctx.stroke();
        p.x = nx;
        p.y = ny;
        p.age++;
        if (p.age > LIFE || p.x < -10 || p.x > W + 10 || p.y < -10 || p.y > H + 10) {
          p.x = Math.random() * W;
          p.y = Math.random() * H;
          p.age = 0;
        }
      }
      t += 0.008;
      raf = requestAnimationFrame(frame);
    }
    frame();
    return function () {
      ro.disconnect();
      cancelAnimationFrame(raf);
    };
  }, []);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      display: 'block',
      pointerEvents: 'none',
      zIndex: 0
    }
  });
}

/* =================================================================
   CloudIcon — SVG cloud with JS sweep beam via strokeDashoffset
   Combined path ensures ONE beam travels all 3 paths in sequence:
   cloud arc → left segment → dot
   ================================================================= */
var CLOUD_COMBINED = "M 5 13.5 A 4 4 0 0 1 7.2 6.3 A 6 6 0 0 1 18.2 8.5 A 4.5 4.5 0 0 1 17.5 17.5 M 11.5 17.5 L 5 17.5 M 14.5 17.5 L 14.51 17.5";
var CLOUD_PATHS_BASE = ["M 5 13.5 A 4 4 0 0 1 7.2 6.3 A 6 6 0 0 1 18.2 8.5 A 4.5 4.5 0 0 1 17.5 17.5", "M 11.5 17.5 L 5 17.5", "M 14.5 17.5 L 14.51 17.5"];
function CloudIcon() {
  var sweepRef = React.useRef(null);
  var haloRef = React.useRef(null);
  React.useEffect(function () {
    var sweep = sweepRef.current;
    var halo = haloRef.current;
    if (!sweep) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var L = sweep.getTotalLength();
    var dashLen = L * 0.09; /* 9% of total = beam width */
    var dur = 3600; /* ms per revolution */

    sweep.style.strokeDasharray = dashLen + ' ' + (L - dashLen);
    if (halo) halo.style.strokeDasharray = dashLen * 2.6 + ' ' + (L - dashLen * 2.6);
    var startTs = null,
      raf;
    function animate(ts) {
      if (!startTs) startTs = ts;
      var elapsed = (ts - startTs) % dur;
      var offset = L * (1 - elapsed / dur);
      sweep.style.strokeDashoffset = offset;
      if (halo) halo.style.strokeDashoffset = offset + dashLen * 0.8;
      raf = requestAnimationFrame(animate);
    }
    raf = requestAnimationFrame(animate);
    return function () {
      cancelAnimationFrame(raf);
    };
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      right: 'clamp(40px, 5vw, 72px)',
      top: 'clamp(88px, 13vw, 148px)',
      width: 252,
      height: 252,
      animation: 'cloud-float 7s ease-in-out infinite',
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "none",
    width: "252",
    height: "252",
    style: {
      overflow: 'visible',
      filter: 'drop-shadow(0 0 7px rgba(0,188,212,0.70)) drop-shadow(0 0 14px rgba(47,85,255,0.40))'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "cloud-grad-cb",
    x1: "0%",
    y1: "100%",
    x2: "100%",
    y2: "0%"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "#00BCD4"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "#2F55FF"
  }))), CLOUD_PATHS_BASE.map(function (d, i) {
    return /*#__PURE__*/React.createElement("path", {
      key: i,
      d: d,
      stroke: "url(#cloud-grad-cb)",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none"
    });
  }), /*#__PURE__*/React.createElement("path", {
    ref: haloRef,
    d: CLOUD_COMBINED,
    fill: "none",
    stroke: "rgba(150,220,255,0.40)",
    strokeWidth: "1.0",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/React.createElement("path", {
    ref: sweepRef,
    d: CLOUD_COMBINED,
    fill: "none",
    stroke: "white",
    strokeWidth: "0.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      filter: 'drop-shadow(0 0 6px rgba(255,255,255,1)) drop-shadow(0 0 2px rgba(200,240,255,0.9))'
    }
  })), /*#__PURE__*/React.createElement("style", null, `
        @keyframes cloud-float {
          0%,100%  { transform: translateY(0px)  translateX(0px);  }
          25%      { transform: translateY(-10px) translateX(7px);  }
          50%      { transform: translateY(-14px) translateX(0px);  }
          75%      { transform: translateY(-9px)  translateX(-7px); }
        }
        @media (max-width: 680px) { [data-cloud] { display: none !important; } }
        @media (prefers-reduced-motion: reduce) {
          @keyframes cloud-float { 0%,100%{ transform: translateY(0px); } }
        }
      `));
}

/* =================================================================
   TypingCursor
   ================================================================= */
function TypingCursor({
  roles
}) {
  var rs = React.useState(0),
    roleIdx = rs[0],
    setRoleIdx = rs[1];
  var ds = React.useState(''),
    displayed = ds[0],
    setDisplayed = ds[1];
  var ts2 = React.useState(true),
    isTyping = ts2[0],
    setIsTyping = ts2[1];
  React.useEffect(function () {
    var role = roles[roleIdx];
    if (isTyping) {
      if (displayed.length < role.length) {
        var id = setTimeout(function () {
          setDisplayed(role.slice(0, displayed.length + 1));
        }, 55);
        return function () {
          clearTimeout(id);
        };
      } else {
        var id2 = setTimeout(function () {
          setIsTyping(false);
        }, 1800);
        return function () {
          clearTimeout(id2);
        };
      }
    } else {
      if (displayed.length > 0) {
        var id3 = setTimeout(function () {
          setDisplayed(displayed.slice(0, -1));
        }, 30);
        return function () {
          clearTimeout(id3);
        };
      } else {
        setRoleIdx((roleIdx + 1) % roles.length);
        setIsTyping(true);
      }
    }
  }, [displayed, isTyping, roleIdx, roles]);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-lg)',
      color: 'var(--text-muted)',
      fontWeight: 400
    }
  }, displayed, /*#__PURE__*/React.createElement("span", {
    style: {
      borderLeft: '2px solid var(--text-muted)',
      marginLeft: 2,
      animation: 'hero-blink 1s step-end infinite'
    }
  }, "\xA0"));
}

/* =================================================================
   Hero
   ================================================================= */
function Hero({
  lang
}) {
  var t = T_HERO[lang];
  var pr = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion:reduce)').matches;
  var r0 = React.useRef(null),
    r1 = React.useRef(null),
    r2 = React.useRef(null),
    r3 = React.useRef(null),
    r4 = React.useRef(null),
    r5 = React.useRef(null);
  React.useEffect(function () {
    if (pr) return;
    var refs = [r0, r1, r2, r3, r4, r5],
      delays = [0, 80, 160, 240, 300, 360];
    refs.forEach(function (ref, i) {
      var el = ref.current;
      if (!el) return;
      setTimeout(function () {
        if (el) {
          el.style.opacity = '1';
          el.style.transform = 'none';
        }
      }, delays[i]);
    });
  }, []);
  var ini = pr ? {
    opacity: 1
  } : {
    opacity: 0,
    transform: 'translateY(22px)'
  };
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      background: 'var(--bg)'
    }
  }, /*#__PURE__*/React.createElement(FlowFieldCanvas, null), /*#__PURE__*/React.createElement(CloudIcon, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 2,
      maxWidth: 'var(--max-width)',
      margin: '0 auto',
      padding: 'clamp(96px,14vw,160px) clamp(20px,4vw,48px) clamp(64px,8vw,96px)',
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: r0,
    style: {
      ...ini,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(StatusDotInline, {
    label: t.available
  })), /*#__PURE__*/React.createElement("h1", {
    ref: r1,
    style: {
      ...ini,
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-display)',
      letterSpacing: 'var(--tracking-display)',
      lineHeight: 'var(--leading-tight)',
      color: 'var(--text)',
      marginBottom: 8
    }
  }, t.name[0], /*#__PURE__*/React.createElement("br", null), t.name[1]), /*#__PURE__*/React.createElement("div", {
    ref: r2,
    style: {
      ...ini,
      marginBottom: 28,
      height: 36,
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(TypingCursor, {
    roles: t.roles
  })), /*#__PURE__*/React.createElement("p", {
    ref: r3,
    style: {
      ...ini,
      maxWidth: 560,
      color: 'var(--text-muted)',
      fontSize: 'var(--text-lg)',
      lineHeight: 'var(--leading-relaxed)',
      marginBottom: 40
    }
  }, t.pitch), /*#__PURE__*/React.createElement("div", {
    ref: r4,
    style: {
      ...ini,
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap',
      marginBottom: 52
    }
  }, /*#__PURE__*/React.createElement(BtnInline, {
    href: "#projects",
    variant: "primary"
  }, t.cta1), /*#__PURE__*/React.createElement(BtnInline, {
    href: "#resume",
    variant: "secondary"
  }, t.cta2)), /*#__PURE__*/React.createElement("div", {
    ref: r5,
    style: {
      ...ini
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      marginBottom: 12
    }
  }, t.tagline), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, STACK.map(function (s, i) {
    return /*#__PURE__*/React.createElement("span", {
      key: s,
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        fontWeight: 500,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        background: 'var(--bg-subtle)',
        borderRadius: 9999,
        padding: '3px 10px',
        lineHeight: 1.5,
        animation: 'stack-wave 4.8s ease-in-out infinite',
        animationDelay: i * 0.21 + 's',
        color: 'var(--text-faint)',
        border: '1px solid var(--border)'
      }
    }, s);
  })))), /*#__PURE__*/React.createElement("style", null, `
        @keyframes hero-blink  { 0%,100%{opacity:1} 50%{opacity:0} }
        @keyframes dot-pulse   { 0%,100%{opacity:0;transform:scale(1)} 50%{opacity:.35;transform:scale(2.2)} }
        @keyframes stack-wave  { 0%,55%,100%{color:var(--text-faint);border-color:var(--border)} 27%{color:var(--text);border-color:var(--border-strong)} }
        @media(prefers-reduced-motion:reduce){
          @keyframes hero-blink  { 0%,100%{opacity:1} }
          @keyframes dot-pulse   { 0%,100%{opacity:0} }
          @keyframes stack-wave  { 0%,100%{color:var(--text-muted)} }
        }
      `));
}

/* ── Sub-components ──────────────────────────────────────────────── */
function StatusDotInline({
  label
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)',
      letterSpacing: '0.04em'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: 8,
      height: 8,
      flexShrink: 0,
      display: 'inline-block'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: '50%',
      background: 'var(--green)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: '-3px',
      borderRadius: '50%',
      background: 'var(--green)',
      opacity: 0,
      animation: 'dot-pulse 2.4s cubic-bezier(.4,0,.6,1) infinite'
    }
  })), label);
}
function BtnInline({
  href,
  variant,
  children
}) {
  var hs = React.useState(false),
    hov = hs[0],
    setHov = hs[1];
  var ip = variant === 'primary';
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      textDecoration: 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500,
      letterSpacing: 'var(--tracking-tight)',
      padding: '9px 20px',
      borderRadius: 'var(--radius-sm)',
      border: '1px solid',
      background: ip ? hov ? 'transparent' : 'var(--accent)' : 'transparent',
      color: ip ? hov ? 'var(--text)' : 'var(--accent-text)' : 'var(--text)',
      borderColor: ip ? 'var(--accent)' : hov ? 'var(--text)' : 'var(--border-strong)',
      transition: 'all var(--duration-fast) var(--ease-default)',
      transform: hov ? 'translateY(-1px)' : 'none'
    },
    onMouseEnter: function () {
      setHov(true);
    },
    onMouseLeave: function () {
      setHov(false);
    }
  }, children);
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Nav.jsx
try { (() => {
/* Nav.jsx — fixed top navigation bar */

const T_NAV = {
  en: {
    links: ['Projects', 'Runbooks', 'Writing', 'About', 'Resume', 'Contact']
  },
  es: {
    links: ['Proyectos', 'Runbooks', 'Escritura', 'Sobre mí', 'Currículum', 'Contacto']
  }
};
function Nav({
  isDark,
  toggleTheme,
  lang,
  setLang
}) {
  const [scrolled, setScrolled] = React.useState(false);
  const t = T_NAV[lang];
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  const hrefs = ['#projects', '#runbooks', '#writing', '#about', '#resume', '#contact'];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 100,
      borderBottom: scrolled ? '1px solid var(--border)' : '1px solid transparent',
      background: scrolled ? 'var(--overlay)' : 'transparent',
      backdropFilter: scrolled ? 'blur(12px)' : 'none',
      WebkitBackdropFilter: scrolled ? 'blur(12px)' : 'none',
      transition: 'background var(--duration-normal) var(--ease-default), border-color var(--duration-normal) var(--ease-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max-width)',
      margin: '0 auto',
      padding: '0 clamp(20px,4vw,48px)',
      height: 56,
      display: 'flex',
      alignItems: 'center',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      textDecoration: 'none',
      color: 'var(--text)',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase'
    }
  }, "ERG")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28,
      flex: 1,
      justifyContent: 'center'
    }
  }, t.links.map((label, i) => /*#__PURE__*/React.createElement(NavLinkInline, {
    key: label,
    href: hrefs[i]
  }, label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setLang(lang === 'en' ? 'es' : 'en'),
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      fontWeight: 600,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      background: 'transparent',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      padding: '5px 10px',
      transition: 'border-color var(--duration-fast) var(--ease-default)'
    },
    onMouseEnter: e => e.currentTarget.style.borderColor = 'var(--border-strong)',
    onMouseLeave: e => e.currentTarget.style.borderColor = 'var(--border)'
  }, lang === 'en' ? 'ES' : 'EN'), /*#__PURE__*/React.createElement("button", {
    "aria-label": isDark ? 'Switch to light mode' : 'Switch to dark mode',
    onClick: toggleTheme,
    style: {
      background: 'transparent',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      width: 34,
      height: 34,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 0,
      transition: 'border-color var(--duration-fast) var(--ease-default), color var(--duration-fast) var(--ease-default)'
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = 'var(--border-strong)';
      e.currentTarget.style.color = 'var(--text)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = 'var(--border)';
      e.currentTarget.style.color = 'var(--text-muted)';
    }
  }, isDark ? /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "5"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "1",
    x2: "12",
    y2: "3"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "21",
    x2: "12",
    y2: "23"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "4.22",
    y1: "4.22",
    x2: "5.64",
    y2: "5.64"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "18.36",
    y1: "18.36",
    x2: "19.78",
    y2: "19.78"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "1",
    y1: "12",
    x2: "3",
    y2: "12"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "21",
    y1: "12",
    x2: "23",
    y2: "12"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "4.22",
    y1: "19.78",
    x2: "5.64",
    y2: "18.36"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "18.36",
    y1: "5.64",
    x2: "19.78",
    y2: "4.22"
  })) : /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z"
  }))))));
}
function NavLinkInline({
  href,
  children
}) {
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    style: {
      position: 'relative',
      textDecoration: 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 500,
      letterSpacing: 'var(--tracking-tight)',
      color: hov ? 'var(--text)' : 'var(--text-muted)',
      transition: 'color var(--duration-fast) var(--ease-default)',
      paddingBottom: 2
    },
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false)
  }, children, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      height: 1,
      background: 'var(--accent)',
      width: hov ? '100%' : '0%',
      transition: 'width var(--duration-normal) var(--ease-default)'
    }
  }));
}
window.Nav = Nav;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Nav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Projects.jsx
try { (() => {
/* Projects.jsx — 3 project cards with spotlight hover effect */

const T_PROJ = {
  en: {
    heading: 'Projects',
    sub: 'Selected infrastructure work',
    ext: 'View ↗'
  },
  es: {
    heading: 'Proyectos',
    sub: 'Trabajo de infraestructura seleccionado',
    ext: 'Ver ↗'
  }
};
const PROJECTS = [{
  title: 'AWS CloudOps Private EC2 Operations Platform',
  desc: 'Private, policy-driven platform for managing EC2 fleets at scale. Covers patch management, compliance automation, and incident response via AWS Systems Manager.',
  tags: ['AWS', 'EC2', 'SSM', 'CloudWatch', 'Bash', 'Patch Management'],
  badge: 'Featured',
  status: 'active',
  href: '#'
}, {
  title: 'Kubernetes Homelab Platform',
  desc: 'Production-grade k3s cluster on Proxmox. GitOps-driven manifests, Terraform-provisioned infrastructure, and full observability stack with Grafana and Prometheus.',
  tags: ['Kubernetes', 'k3s', 'Terraform', 'Proxmox', 'GitOps'],
  badge: null,
  status: 'active',
  href: '#'
}, {
  title: 'AWS CloudWatch Observability Stack',
  desc: 'Unified observability layer across multi-account AWS environments — custom dashboards, composite alarms, log insights queries, and PagerDuty integration.',
  tags: ['CloudWatch', 'AWS', 'Terraform', 'Bash', 'SNS'],
  badge: null,
  status: 'active',
  href: '#'
}];
function Projects({
  lang
}) {
  const t = T_PROJ[lang];
  return /*#__PURE__*/React.createElement("section", {
    id: "projects",
    style: {
      padding: 'var(--section-gap) clamp(20px,4vw,48px)',
      background: 'var(--bg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max-width)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    label: "01",
    heading: t.heading,
    sub: t.sub
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
      gap: 16
    }
  }, PROJECTS.map((p, i) => /*#__PURE__*/React.createElement(ProjectCard, {
    key: p.title,
    project: p,
    ext: t.ext,
    idx: i
  })))));
}
function ProjectCard({
  project,
  ext,
  idx
}) {
  const cardRef = React.useRef(null);
  const [hov, setHov] = React.useState(false);
  const onMouseMove = e => {
    const el = cardRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', (e.clientX - r.left) / r.width * 100 + '%');
    el.style.setProperty('--my', (e.clientY - r.top) / r.height * 100 + '%');
  };
  return /*#__PURE__*/React.createElement("a", {
    ref: cardRef,
    href: project.href,
    className: "fade-in",
    onMouseMove: onMouseMove,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      '--mx': '50%',
      '--my': '50%',
      position: 'relative',
      overflow: 'hidden',
      display: 'block',
      textDecoration: 'none',
      color: 'inherit',
      background: 'var(--surface)',
      border: '1px solid',
      borderColor: hov ? 'var(--border-strong)' : 'var(--border)',
      borderRadius: 'var(--radius)',
      padding: 'var(--card-pad)',
      transform: hov ? 'scale(1.015) translateY(-3px)' : 'none',
      boxShadow: hov ? 'var(--shadow-md)' : 'none',
      transition: 'transform 200ms cubic-bezier(.4,0,.2,1), box-shadow 200ms cubic-bezier(.4,0,.2,1), border-color 120ms cubic-bezier(.4,0,.2,1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none',
      zIndex: 0,
      borderRadius: 'inherit',
      background: 'radial-gradient(380px circle at var(--mx) var(--my), var(--spotlight), transparent 70%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, project.badge && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--accent)',
      border: '1px solid var(--accent)',
      borderRadius: 'var(--radius-sm)',
      padding: '2px 7px'
    }
  }, project.badge), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      padding: '2px 7px'
    }
  }, project.status)), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      color: 'var(--text-faint)',
      flexShrink: 0,
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "15 3 21 3 21 9"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "10",
    y1: "14",
    x2: "21",
    y2: "3"
  }))), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 'var(--text-base)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text)',
      lineHeight: 'var(--leading-snug)',
      flex: 1
    }
  }, project.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-normal)',
      marginBottom: 8
    }
  }, project.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, project.tags.map(tag => /*#__PURE__*/React.createElement("span", {
    key: tag,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 500,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      background: 'var(--bg-subtle)',
      border: '1px solid var(--border)',
      borderRadius: 9999,
      padding: '2px 8px'
    }
  }, tag)))));
}
function SectionHeader({
  label,
  heading,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 36
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      display: 'block',
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-h2)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text)',
      lineHeight: 'var(--leading-tight)',
      marginBottom: 6
    }
  }, heading), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, sub));
}
window.Projects = Projects;
window.SectionHeader = SectionHeader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Projects.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Runbooks.jsx
try { (() => {
/* Runbooks.jsx — collapsible runbook cards with severity badges */

const T_RUN = {
  en: {
    heading: 'Runbooks',
    sub: 'Field-tested operational procedures',
    expand: 'Expand',
    collapse: 'Collapse'
  },
  es: {
    heading: 'Runbooks',
    sub: 'Procedimientos operativos probados en campo',
    expand: 'Expandir',
    collapse: 'Colapsar'
  }
};
const RUNBOOKS = [{
  title: 'EC2 Instance Unreachable via SSM Session Manager',
  severity: 'P2',
  status: 'stable',
  time: '~15 min',
  tags: ['AWS', 'EC2', 'SSM', 'CloudWatch', 'IAM'],
  desc: 'Systematic triage for EC2 instances that fail to register with SSM. Covers IAM role misconfiguration, missing SSM agent, VPC endpoint routing, and network ACL issues.',
  steps: ['Verify instance profile has AmazonSSMManagedInstanceCore policy attached.', 'Check SSM agent status: aws ssm describe-instance-information --filters "Key=InstanceIds,Values=i-xxxx"', 'Inspect CloudWatch agent logs at /var/log/amazon/ssm/amazon-ssm-agent.log', 'Confirm VPC has com.amazonaws.<region>.ssm endpoint or NAT gateway for outbound access.', 'Validate security group allows HTTPS (443) outbound to SSM endpoints.', 'If instance was recently patched, verify agent was not removed during cleanup.']
}, {
  title: 'Kubernetes Node NotReady — Systematic Recovery',
  severity: 'P3',
  status: 'stable',
  time: '~10 min',
  tags: ['Kubernetes', 'kubectl', 'kubelet', 'containerd'],
  desc: 'Step-by-step recovery for nodes stuck in NotReady state. Covers kubelet failures, disk pressure, network plugin issues, and certificate rotation edge cases.',
  steps: ['Describe the node: kubectl describe node <node-name> — check Conditions and Events.', 'SSH into the node and verify kubelet: systemctl status kubelet', 'Check logs: journalctl -u kubelet --no-pager -n 100', 'Inspect disk pressure: df -h and check /var/lib/kubelet and /var/lib/containerd.', 'Verify CNI plugin is running: ls /etc/cni/net.d/ and check plugin pod status.', 'If cert issue: kubeadm certs check-expiration and rotate as needed.']
}];
function Runbooks({
  lang
}) {
  const t = T_RUN[lang];
  return /*#__PURE__*/React.createElement("section", {
    id: "runbooks",
    style: {
      padding: 'var(--section-gap) clamp(20px,4vw,48px)',
      background: 'var(--bg-subtle)',
      borderTop: '1px solid var(--border)',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max-width)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(window.SectionHeader, {
    label: "02",
    heading: t.heading,
    sub: t.sub
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, RUNBOOKS.map((rb, i) => /*#__PURE__*/React.createElement(RunbookCard, {
    key: rb.title,
    runbook: rb,
    t: t,
    idx: i
  })))));
}
function RunbookCard({
  runbook,
  t,
  idx
}) {
  const [open, setOpen] = React.useState(false);
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "fade-in",
    style: {
      background: 'var(--surface)',
      border: '1px solid',
      borderColor: hov || open ? 'var(--border-strong)' : 'var(--border)',
      borderRadius: 'var(--radius)',
      overflow: 'hidden',
      transition: 'border-color 120ms cubic-bezier(.4,0,.2,1)'
    },
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false)
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(o => !o),
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '18px 24px',
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text)',
      border: '1px solid var(--border-strong)',
      borderRadius: 'var(--radius-sm)',
      padding: '3px 8px',
      background: 'var(--bg-subtle)',
      flexShrink: 0
    }
  }, runbook.severity), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 'var(--text-base)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text)',
      flex: 1,
      lineHeight: 'var(--leading-snug)'
    }
  }, runbook.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-faint)',
      letterSpacing: '0.04em'
    }
  }, runbook.time), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      padding: '2px 7px'
    }
  }, runbook.status), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      color: 'var(--text-faint)',
      transform: open ? 'rotate(180deg)' : 'none',
      transition: 'transform 200ms cubic-bezier(.4,0,.2,1)'
    }
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 24px 16px',
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, runbook.tags.map(tag => /*#__PURE__*/React.createElement("span", {
    key: tag,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 500,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      background: 'var(--bg-subtle)',
      border: '1px solid var(--border)',
      borderRadius: 9999,
      padding: '2px 8px'
    }
  }, tag))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: open ? '800px' : '0',
      overflow: 'hidden',
      transition: 'max-height 320ms cubic-bezier(.4,0,.2,1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 24px 24px',
      borderTop: '1px solid var(--border)',
      paddingTop: 20
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-normal)',
      marginBottom: 20
    }
  }, runbook.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, runbook.steps.map((step, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-faint)',
      flexShrink: 0,
      paddingTop: 2,
      minWidth: 20
    }
  }, String(i + 1).padStart(2, '0')), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-normal)',
      fontFamily: step.startsWith('aws ') || step.startsWith('kubectl') || step.startsWith('systemctl') || step.startsWith('journalctl') || step.startsWith('kubeadm') ? 'var(--font-mono)' : 'inherit',
      fontSize: step.startsWith('aws ') || step.startsWith('kubectl') || step.startsWith('systemctl') || step.startsWith('journalctl') || step.startsWith('kubeadm') ? 12 : 'var(--text-sm)'
    }
  }, step)))))));
}
window.Runbooks = Runbooks;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Runbooks.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Terminal.jsx
try { (() => {
/* Terminal.jsx — interactive emulated terminal */

const T_TERM = {
  en: {
    heading: 'Terminal',
    label: 'Interactive CLI',
    hint: 'Click a command to execute'
  },
  es: {
    heading: 'Terminal',
    label: 'CLI Interactivo',
    hint: 'Haz clic en un comando para ejecutarlo'
  }
};
const COMMANDS = {
  'cat projects.md': ['# Projects', '', '## AWS CloudOps Private EC2 Operations Platform', '   tags: AWS, EC2, SSM, CloudWatch, Bash', '   status: active · featured', '', '## Kubernetes Homelab Platform', '   tags: Kubernetes, k3s, Terraform, Proxmox', '   status: active', '', '## AWS CloudWatch Observability Stack', '   tags: CloudWatch, AWS, Terraform, Bash', '   status: active'],
  'ls runbooks/': ['drwxr-xr-x  ec2-ssm-unreachable.md    [P2] [stable]', 'drwxr-xr-x  k8s-node-notready.md      [P3] [stable]'],
  'whoami': ['elvis.gross', 'roles: cloudops-engineer, platform-engineer, sre', 'cloud: aws, gcp', 'status: available-for-new-roles', 'location: remote']
};
function Terminal({
  lang
}) {
  const t = T_TERM[lang];
  const [history, setHistory] = React.useState([]);
  const [running, setRunning] = React.useState(null);
  const outputRef = React.useRef(null);
  const run = cmd => {
    if (running) return;
    setRunning(cmd);
    const lines = COMMANDS[cmd] || ['command not found'];
    let i = 0;
    const id = setInterval(() => {
      setHistory(h => [...h, {
        cmd: i === 0 ? cmd : null,
        line: lines[i]
      }]);
      i++;
      if (i >= lines.length) {
        clearInterval(id);
        setRunning(null);
        setTimeout(() => {
          if (outputRef.current) {
            outputRef.current.scrollTop = outputRef.current.scrollHeight;
          }
        }, 30);
      }
    }, 55);
  };
  const clear = () => setHistory([]);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--bg-subtle)',
      borderTop: '1px solid var(--border)',
      borderBottom: '1px solid var(--border)',
      padding: 'var(--content-gap) clamp(20px,4vw,48px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max-width)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "fade-in",
    style: {
      background: '#0b0b0b',
      border: '1px solid #1f1f1f',
      borderRadius: 'var(--radius)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-dark-md)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '10px 16px',
      borderBottom: '1px solid #1f1f1f',
      background: '#111111'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 11,
      height: 11,
      borderRadius: '50%',
      background: '#3a3a3a',
      display: 'inline-block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 11,
      height: 11,
      borderRadius: '50%',
      background: '#3a3a3a',
      display: 'inline-block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 11,
      height: 11,
      borderRadius: '50%',
      background: '#3a3a3a',
      display: 'inline-block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: '#6b6b6b',
      letterSpacing: '0.06em'
    }
  }, "elvis@ops:~"), /*#__PURE__*/React.createElement("button", {
    onClick: clear,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: '#6b6b6b',
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      transition: 'color var(--duration-fast) var(--ease-default)'
    },
    onMouseEnter: e => e.currentTarget.style.color = '#9a9a9a',
    onMouseLeave: e => e.currentTarget.style.color = '#6b6b6b'
  }, "clear")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      borderBottom: '1px solid #1f1f1f',
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, Object.keys(COMMANDS).map(cmd => /*#__PURE__*/React.createElement("button", {
    key: cmd,
    onClick: () => run(cmd),
    disabled: !!running,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      fontWeight: 500,
      color: running ? '#3a3a3a' : '#9a9a9a',
      background: '#161616',
      border: '1px solid #2a2a2a',
      borderRadius: 'var(--radius-sm)',
      padding: '5px 12px',
      cursor: running ? 'not-allowed' : 'pointer',
      transition: 'color var(--duration-fast) var(--ease-default), border-color var(--duration-fast) var(--ease-default)'
    },
    onMouseEnter: e => {
      if (!running) {
        e.currentTarget.style.color = '#f2f2f2';
        e.currentTarget.style.borderColor = '#3a3a3a';
      }
    },
    onMouseLeave: e => {
      e.currentTarget.style.color = running ? '#3a3a3a' : '#9a9a9a';
      e.currentTarget.style.borderColor = '#2a2a2a';
    }
  }, "$ ", cmd))), /*#__PURE__*/React.createElement("div", {
    ref: outputRef,
    style: {
      padding: '16px 20px',
      minHeight: 160,
      maxHeight: 280,
      overflowY: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      lineHeight: 1.75,
      color: '#9a9a9a'
    }
  }, history.length === 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#3a3a3a'
    }
  }, lang === 'en' ? '// click a command above to execute' : '// haz clic en un comando para ejecutar') : history.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, item.cmd && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: i > 0 ? 8 : 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#6b6b6b'
    }
  }, "elvis@ops:~$ "), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#f2f2f2'
    }
  }, item.cmd)), item.line !== undefined && /*#__PURE__*/React.createElement("div", {
    style: {
      color: item.line === '' ? undefined : '#9a9a9a',
      paddingLeft: item.cmd ? 0 : '2ch'
    }
  }, item.line || '\u00a0'))), !running && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: history.length ? 8 : 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#6b6b6b'
    }
  }, "elvis@ops:~$ "), /*#__PURE__*/React.createElement("span", {
    style: {
      borderLeft: '2px solid #6b6b6b',
      animation: 'blink-cursor 1s step-end infinite'
    }
  }, "\xA0")))), /*#__PURE__*/React.createElement("style", null, `@keyframes blink-cursor{0%,100%{opacity:1}50%{opacity:0}}`)));
}
window.Terminal = Terminal;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Terminal.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Writing.jsx
try { (() => {
/* Writing.jsx — technical notes section */

const T_WRITE = {
  en: {
    heading: 'Writing',
    sub: 'Technical notes and field observations',
    read: 'Read →'
  },
  es: {
    heading: 'Escritura',
    sub: 'Notas técnicas y observaciones de campo',
    read: 'Leer →'
  }
};
const POSTS = [{
  title: 'Running k3s on Proxmox: A Production-Grade Homelab',
  category: 'Infrastructure',
  date: 'Jan 2025',
  desc: 'How I set up a lightweight Kubernetes cluster on Proxmox VE using k3s, Terraform for VM provisioning, and Flux CD for GitOps-driven deployments. Covers storage, networking, and observability.',
  href: '#'
}, {
  title: 'EC2 Golden AMI Pipelines with Packer and AWS Image Builder',
  category: 'AWS',
  date: 'Nov 2024',
  desc: 'A walkthrough of building hardened, pre-patched AMIs that comply with CIS benchmarks. Covers pipeline architecture, testing gates, automated distribution, and integration with AWS Systems Manager.',
  href: '#'
}];
function Writing({
  lang
}) {
  const t = T_WRITE[lang];
  return /*#__PURE__*/React.createElement("section", {
    id: "writing",
    style: {
      padding: 'var(--section-gap) clamp(20px,4vw,48px)',
      background: 'var(--bg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--max-width)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(window.SectionHeader, {
    label: "03",
    heading: t.heading,
    sub: t.sub
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 1
    }
  }, POSTS.map((post, i) => /*#__PURE__*/React.createElement(WritingRow, {
    key: post.title,
    post: post,
    read: t.read,
    idx: i
  })))));
}
function WritingRow({
  post,
  read,
  idx
}) {
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: post.href,
    className: "fade-in",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 24,
      padding: '24px 0',
      textDecoration: 'none',
      color: 'inherit',
      borderBottom: '1px solid var(--border)',
      transition: 'opacity var(--duration-fast) var(--ease-default)',
      opacity: hov ? 1 : 0.92
    },
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      width: 120,
      paddingTop: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-faint)',
      letterSpacing: '0.06em',
      marginBottom: 4
    }
  }, post.date), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-block',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      border: '1px solid var(--border)',
      borderRadius: 9999,
      padding: '2px 8px'
    }
  }, post.category)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 'var(--text-base)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text)',
      lineHeight: 'var(--leading-snug)',
      marginBottom: 8
    }
  }, post.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-normal)'
    }
  }, post.desc)), /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: hov ? 'var(--text)' : 'var(--text-faint)',
      transition: 'color var(--duration-fast) var(--ease-default), transform var(--duration-fast) var(--ease-default)',
      transform: hov ? 'translateX(4px)' : 'none',
      paddingTop: 2
    }
  }, read));
}
window.Writing = Writing;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Writing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.NavLink = __ds_scope.NavLink;

__ds_ns.StatusDot = __ds_scope.StatusDot;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.ThemeToggle = __ds_scope.ThemeToggle;

})();

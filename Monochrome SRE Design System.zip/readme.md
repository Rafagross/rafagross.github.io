# Monochrome SRE Design System

A **deluxe monochromatic** design system for Elvis Rafael Gross's personal portfolio. The aesthetic is modeled after the refined minimalism of Linear and Vercel — technical, precise, and interactively alive. Zero gratuitous color; every visual decision earns its place.

---

## Sources & Context

| Resource | Details |
|---|---|
| Primary brief | Inline specification (pasted prompt) |
| No external Figma/GitHub | Design is authored from scratch per spec |

The portfolio belongs to **Elvis Rafael Gross**, a CloudOps/Platform/SRE engineer. There is no existing product codebase; this design system is built entirely from the written specification.

---

## Product Context

**Roles:** CloudOps Engineer · Platform Engineer · SRE  
**Pitch:** builds and operates cloud infrastructure at scale — AWS EC2 fleets, Kubernetes platforms, hybrid architectures, and the observability layer that keeps them running.  
**Status:** Available for new roles (live green dot)  
**Language:** English primary; optional Spanish toggle.

### Navigation Order (canonical, never reorder)
`Projects` → `Runbooks` → `Writing` → `About` → `Resume` → `Contact`

### Tech Stack Tags
AWS · GCP · Terraform · Kubernetes · Golden AMI Pipelines · CloudWatch · Bash · AWS Systems Manager · AWS CLI · Patch Management

---

## Content Fundamentals

**Voice & Tone**
- First-person, direct, confident — "I build…" not "Elvis builds…"  
- Technical but not jargon-padded. Every noun earns its presence.  
- No em-dashes for decoration; use them surgically.  
- No ellipses. No exclamation marks. No filler adjectives ("amazing," "robust," "powerful").  
- Dry, precise SRE energy: the person who writes runbooks, not marketing copy.  

**Casing**
- Nav links: Title Case (Projects, Runbooks, Writing)  
- Section headers: sentence case ("Recent projects", "Field runbooks")  
- Badge/tag labels: UPPERCASE mono (e.g. `AWS`, `P2`, `stable`)  
- Body copy: normal sentence case  

**Numbers & Technical Labels**
- Time estimates in runbooks: `~15 min` format  
- Severity: `P1` / `P2` / `P3` (monospaced)  
- Status: `stable` · `active` · `deprecated`  

**Emoji Usage**
- None. Zero. The aesthetic is purely typographic.  

**What to Write, What to Omit**
- No bio fluff. No "passionate about" phrasing.  
- Projects: name, 1-line description, tags, status badge.  
- Runbooks: title, severity, time estimate, status, brief description.  
- Writing: title, date, category tag — that's it.  

---

## Visual Foundations

### Color
Strictly monochromatic. The palette is a grayscale ramp with a single hue exception.

| Token | Light | Dark | Role |
|---|---|---|---|
| `--bg` | `#ffffff` | `#0b0b0b` | Page background |
| `--bg-subtle` | `#fafafa` | `#0e0e0e` | Inset / alternating sections |
| `--surface` | `#ffffff` | `#111111` | Cards, panels |
| `--border` | `#e6e6e6` | `#1f1f1f` | Default hairline |
| `--border-strong` | `#d4d4d4` | `#2a2a2a` | Hover / emphasized |
| `--text` | `#0a0a0a` | `#f2f2f2` | Primary copy |
| `--text-muted` | `#6b6b6b` | `#9a9a9a` | Secondary copy (WCAG AA) |
| `--accent` | `#0a0a0a` | `#ffffff` | Accent = inverted from bg |
| `--green` | `#3fb950` | `#3fb950` | "Available" dot only |

**One permitted hue:** `--green: #3fb950` for the availability status indicator exclusively.

### Typography
- **Display (H1):** Space Grotesk 700, `--text-display` (~56–64px fluid), `letter-spacing: -0.04em`. Tight, intentional, not playful.  
- **Headings (H2/H3):** Space Grotesk 600, `letter-spacing: -0.02em`.  
- **Body:** Space Grotesk 400–500, 1rem, `line-height: 1.55`. Readable, not squeezed.  
- **Technical / Mono:** JetBrains Mono — used for all tags, badges, severity markers, metrics, terminal output, and code. Carries the SRE/industrial identity.  
- **Never use Inter, Roboto, or Arial.**  

### Backgrounds & Textures
- **Hero (dark):** `#0b0b0b` base with a CSS-gradient grid of `#1f1f1f` lines at 1px — near-invisible scaffolding. A radial gradient "halo" follows the cursor for depth.
- **Light mode hero:** white with very faint `rgba(10,10,10,0.04)` grid.
- No photographic backgrounds, no grain, no blurs behind text.
- Sections alternate between `--bg` and `--bg-subtle` for rhythm.

### Cards
- `border: 1px solid var(--border)` default  
- `border-radius: var(--radius)` (10px)  
- `background: var(--surface)`  
- No default shadow (shadow is earned on hover)  
- Hover: border → `--border-strong`, `transform: scale(1.02) translateY(-4px)`, subtle shadow, spotlight radial gradient tracking mouse  
- Transition: `200ms cubic-bezier(.4,0,.2,1)`  

### Spotlight Effect (cards)
A `radial-gradient` centered on `--mouse-x / --mouse-y` CSS variables, blending a faint `--spotlight` tint. This is the key "alive" microinteraction.

### Animations & Motion
- **Entry:** `opacity: 0 → 1` + `translateY(20px → 0)` via `IntersectionObserver`. Staggered 80ms per item. Gate on `[data-deck-active]` / reduced-motion media query.  
- **Typing effect:** optional on the hero subtitle roles.  
- **Easing:** always `cubic-bezier(.4,0,.2,1)` — the "Material standard" fast-in / ease-out curve.  
- **No bounce, no spring pop, no infinite decorative loops.**  
- `prefers-reduced-motion`: kills all animation durations to 0.  

### Borders & Surfaces
- All borders 1px. Never 2px decorative borders or colored left-accent bars.  
- No box-shadows on surfaces at rest. Shadow only on hover/active state.  
- In dark mode, borders are near-invisible (`#1f1f1f` on `#0b0b0b`).  

### Corner Radii
- `--radius-sm`: 6px — badges, tags  
- `--radius`: 10px — cards, panels  
- `--radius-lg`: 16px — modals, large surfaces  
- `--radius-full`: 9999px — pill chips, dots, toggles  

### Hover & Press States
- Links: animated underline that scales from `0 → 100%` width. No color change.  
- Buttons: `background-color` darkens/lightens by ~10%, transition 120ms.  
- Cards: `scale(1.02) translateY(-4px)` — no color shift, depth via transform + shadow.  
- Nav items: underline that animates in from left.  
- Icon buttons: `opacity: 0.6 → 1`.  

### Focus
- All interactive elements: `outline: 2px solid var(--accent); outline-offset: 3px`  
- Never `outline: none` without a visible replacement.  

### Transparency & Blur
- No backdrop-blur. Avoids the overused frosted-glass aesthetic.  
- Overlays use `--overlay` (white/black at ~72% opacity).  

### Imagery & Iconography
- No photography in the portfolio itself.  
- Lucide icons (CDN) for UI affordances — consistent 16px stroke-2 style.  
- No emoji, no custom drawn SVGs, no icon fonts.  
- The terminal emulator is a key "visual" element — dark panel, monospaced, blinking cursor.  

### Layout
- `max-width: 1100px`, centered, `padding: 0 clamp(24px, 5vw, 48px)`.  
- 12-column CSS Grid where needed; flex-gap for card rows.  
- No fixed sidebars. Nav is top-fixed, transparent → frosted on scroll.  

---

## Iconography

**System:** Lucide Icons loaded from CDN (`https://unpkg.com/lucide@latest/dist/umd/lucide.min.js`).  
**Style:** 16–20px, `stroke-width: 1.5`, color: `currentColor`.  
**Usage:** Navigation affordances, runbook severity icons, project "external link" indicators, theme toggle (sun/moon).  
**Emoji:** Never.  
**Custom SVGs:** None.  
**Assets:** No icon font in `assets/` — Lucide CDN is the sole source.

---

## File Index

```
styles.css                      ← Consumer entry point (imports only)
tokens/
  colors.css                    ← Color custom properties (both themes)
  typography.css                ← Font families, scale, weight tokens
  spacing.css                   ← Space, radius, shadow, layout tokens
  motion.css                    ← Easing, duration, composite transitions
  fonts.css                     ← Google Fonts @import (Space Grotesk + JetBrains Mono)
components/core/
  Button.jsx / .d.ts / .prompt.md
  Badge.jsx  / .d.ts / .prompt.md
  Tag.jsx    / .d.ts / .prompt.md
  Card.jsx   / .d.ts / .prompt.md
  StatusDot.jsx / .d.ts / .prompt.md
  ThemeToggle.jsx / .d.ts / .prompt.md
  NavLink.jsx / .d.ts / .prompt.md
  core.card.html                ← @dsCard for all core components
ui_kits/portfolio/
  index.html                    ← Full interactive portfolio recreation
  Hero.jsx
  Projects.jsx
  Runbooks.jsx
  Writing.jsx
  Footer.jsx
  Nav.jsx
  Terminal.jsx
guidelines/
  colors.card.html              ← @dsCard: color swatches
  type.card.html                ← @dsCard: type scale specimen
  mono.card.html                ← @dsCard: mono type specimen
  spacing.card.html             ← @dsCard: spacing scale
  motion.card.html              ← @dsCard: easing curves
  shadows.card.html             ← @dsCard: shadow ramp
  radii.card.html               ← @dsCard: border radii
templates/portfolio/
  index.html                    ← @template: portfolio starting point
  ds-base.js
assets/
  (No binary assets — fonts loaded from CDN)
readme.md                       ← This file
SKILL.md                        ← Claude Code skill definition
```

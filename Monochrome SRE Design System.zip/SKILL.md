---
name: monochrome-sre-design
description: Use this skill to generate well-branded interfaces and assets for the Monochrome SRE Design System — a deluxe, minimalist, monochromatic design system for CloudOps/Platform/SRE engineers. Contains essential design guidelines, color tokens, typography, component library, and a full interactive portfolio UI kit.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick Reference

**Color system:** Strictly monochromatic. Token names: `--bg`, `--bg-subtle`, `--surface`, `--border`, `--border-strong`, `--text`, `--text-muted`, `--text-faint`, `--accent`, `--accent-text`. Toggle via `data-theme="light|dark"` on `<html>`. The only non-grayscale value is `--green: #3fb950` for status dots.

**Fonts:** Space Grotesk (display/sans) + JetBrains Mono (technical/mono). Both from Google Fonts CDN.

**Components (via `window.MonochromeSREDesignSystem_10ba68`):** Button, Badge, Tag, Card, StatusDot, ThemeToggle, NavLink.

**Key microinteractions:**
- Cards: spotlight radial gradient tracks `--mouse-x`/`--mouse-y` + `scale(1.015) translateY(-3px)` on hover
- Nav links: animated underline width 0→100%
- Hero: grid background + cursor-tracked halo radial gradient
- Runbooks: max-height collapse/expand transition
- Scroll: IntersectionObserver fade-in on `.fade-in` elements

**No-fly zone:** No color except grayscale + green dot. No Inter/Roboto/Arial. No emoji. No colored left-border accent cards. No backdrop-blur on content. No box-shadows at rest.
